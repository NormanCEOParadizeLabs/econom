"""YAPR API: authenticated uploads, persistent jobs, transcription, Claude planning, real MP4 renders."""
import json
import os
import shutil
import subprocess
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Annotated
from urllib.parse import quote

import httpx
from fastapi import FastAPI, BackgroundTasks, Depends, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .ai import transcribe, claude_edit_plan, safe_simple_title
from .engine import STYLES, extract_audio, detect_silences, intervals_from_silence, normalize_cuts, probe, render_ffmpeg
from .hyperframes import create_composition, render as render_hyperframes

ROOT=Path(__file__).resolve().parents[1]
WORKDIR=Path(os.environ.get("YAPR_RUNTIME",str(ROOT/"runtime")))
WORKDIR.mkdir(parents=True,exist_ok=True)
MAX_UPLOAD=int(os.environ.get("MAX_UPLOAD_MB","50"))*1024*1024
MAX_DURATION=int(os.environ.get("MAX_VIDEO_SECONDS","600"))
PRODUCTION=os.getenv("APP_ENV","development").lower()=="production"
SUPABASE_URL=os.getenv("SUPABASE_URL","").rstrip("/")
PUB_KEY=os.getenv("SUPABASE_PUBLISHABLE_KEY","")
CLOUD=bool(SUPABASE_URL and PUB_KEY)
GATE=threading.BoundedSemaphore(int(os.getenv("MAX_ACTIVE_JOBS","1")))

app=FastAPI(title="YAPR. API",description="Montage vidéo automatique spécialisé YAP",version="0.1.0")


def conn():
    db=sqlite3.connect(str(WORKDIR/"jobs.sqlite"),timeout=30)
    db.row_factory=sqlite3.Row
    return db

with conn() as db:
    db.execute("""CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
        status TEXT NOT NULL, progress INTEGER NOT NULL, style TEXT NOT NULL,
        title TEXT NOT NULL, source_path TEXT, output_path TEXT,
        raw_storage_path TEXT, output_storage_path TEXT, transcript TEXT,
        cuts TEXT, render_engine TEXT, error TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")


def supabase_headers(token:str):
    if CLOUD and not token: raise ValueError("Session Supabase manquante")
    return {"apikey":PUB_KEY,"Authorization":f"Bearer {token}"}


def save(job:dict,token:str=""):
    columns=['id','user_id','status','progress','style','title','source_path','output_path',
             'raw_storage_path','output_storage_path','transcript','cuts','render_engine','error']
    values=[job.get(x) for x in columns]
    with conn() as db:
        db.execute(f"INSERT INTO jobs ({','.join(columns)}) VALUES ({','.join(['?']*len(columns))}) "
                   f"ON CONFLICT(id) DO UPDATE SET {','.join(c+'=excluded.'+c for c in columns if c!='id')}",values)
    if CLOUD:
        cloud_fields={k:job.get(k) for k in ['id','user_id','status','progress','style','title','raw_storage_path','output_storage_path','transcript','cuts','render_engine','error']}
        # Never persist internal host filesystem paths to public Data API.
        with httpx.Client(timeout=20) as client:
            resp=client.post(f"{SUPABASE_URL}/rest/v1/yapr_jobs",json=cloud_fields,
                headers={**supabase_headers(token),"Prefer":"resolution=merge-duplicates,return=minimal"})
            resp.raise_for_status()


def local_job(job_id):
    with conn() as db:
        row=db.execute("SELECT * FROM jobs WHERE id=?",(job_id,)).fetchone()
    return dict(row) if row else None


def public_job(job):
    return {k:job.get(k) for k in ['id','status','progress','style','title','error','created_at','render_engine']}


def cloud_job(job_id:str,user_id:str,token:str)->dict|None:
    with httpx.Client(timeout=15) as client:
        r=client.get(f"{SUPABASE_URL}/rest/v1/yapr_jobs",params={"id":"eq."+job_id,"user_id":"eq."+user_id,"select":"*"},headers=supabase_headers(token))
        r.raise_for_status()
        data=r.json()
        return data[0] if data else None


def require_config():
    if PRODUCTION and not CLOUD:
        raise HTTPException(503,"Configuration Supabase nécessaire avant l'ouverture au public.")


def require_user(authorization: Annotated[str|None,Header()] = None) -> str:
    require_config()
    if not CLOUD:
        return "demo-local"
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401,"Connecte-toi pour continuer.")
    with httpx.Client(timeout=15) as client:
        try:
            r=client.get(f"{SUPABASE_URL}/auth/v1/user",headers={"apikey":PUB_KEY,"Authorization":authorization})
        except httpx.HTTPError:
            raise HTTPException(502,"Authentification indisponible.")
    if r.status_code!=200:raise HTTPException(401,"Session expirée. Reconnecte-toi.")
    user=r.json()
    if not user.get("id"):raise HTTPException(401,"Utilisateur non reconnu.")
    return user["id"]


@app.get("/api/health")
def health():
    return {"status":"ok","version":"0.1.0","production":PRODUCTION,"supabase":CLOUD,
            "claude":bool(os.getenv("ANTHROPIC_API_KEY")),"transcription":bool(os.getenv("OPENAI_API_KEY"))}


@app.get("/api/config")
def config():
    return {"name":"YAPR.","supabase":bool(SUPABASE_URL and PUB_KEY),"supabaseUrl":SUPABASE_URL,"publishableKey":PUB_KEY,"authRequired":CLOUD,
            "ready":(CLOUD if PRODUCTION else True),"demo":not CLOUD,
            "maxUploadMB":round(MAX_UPLOAD/1024/1024),"styles":STYLES,
            "capabilities":{"autoCut":True,"captions":bool(os.getenv("OPENAI_API_KEY")),
                "claude":bool(os.getenv("ANTHROPIC_API_KEY")),
                "hyperframes":bool(os.getenv("HYPERFRAMES_ENABLED","false").lower()=="true")}}


class JobResponse(BaseModel):
    id:str
    status:str
    progress:int
    title:str
    style:str
    error:str|None=None
    render_engine:str|None=None
    created_at:str|None=None


@app.post("/api/jobs",status_code=201)
async def create_job(background:BackgroundTasks, video:UploadFile=File(...), style:str=Form("impact"),
                     note:str=Form(""), user_id:str=Depends(require_user), authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ") if CLOUD else ""
    if style not in STYLES:raise HTTPException(422,"Style de montage inconnu.")
    # MVP anti-abuse: only a small number of daily renders per account.
    if CLOUD:
        with httpx.Client(timeout=15) as client:
            chk=client.get(f"{SUPABASE_URL}/rest/v1/yapr_jobs",
                params={"user_id":"eq."+user_id,"select":"id,created_at,status","order":"created_at.desc","limit":"15"},
                headers=supabase_headers(token))
            chk.raise_for_status()
            recent=chk.json()
            day=time.strftime("%Y-%m-%d",time.gmtime())
            if sum(str(j.get("created_at","")).startswith(day) for j in recent)>=5:
                raise HTTPException(429,"Limite de 5 vidéos par jour pour cette version de test.")
            if any(j.get("status") not in ("completed","failed") for j in recent):
                raise HTTPException(429,"Tu as déjà une vidéo en cours. Réessaie après son montage.")
    suffix=Path(video.filename or "").suffix.lower()
    if suffix not in ('.mp4','.mov','.m4v','.webm'):
        raise HTTPException(415,"Formats acceptés : MP4, MOV, M4V ou WebM.")
    job_id=str(uuid.uuid4())
    folder=WORKDIR/job_id
    folder.mkdir(parents=True,exist_ok=True)
    src=folder/("source"+suffix)
    size=0
    try:
        with open(src,'wb') as f:
            while data:=await video.read(1024*1024):
                size+=len(data)
                if size>MAX_UPLOAD:
                    raise HTTPException(413,f"Cette vidéo dépasse {round(MAX_UPLOAD/1024/1024)} Mo.")
                f.write(data)
        if size<1024:raise HTTPException(400,"Fichier trop petit ou vide.")
        try: meta=probe(str(src))
        except Exception:
            raise HTTPException(400,"Ce fichier ne peut pas être lu comme une vidéo.")
        if meta['duration']<2 or meta['duration']>MAX_DURATION:
            raise HTTPException(422,f"Durée autorisée : de 2 à {MAX_DURATION//60} minutes.")
        if not meta['audio']:raise HTTPException(422,"La vidéo ne contient pas de piste audio.")
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise
    job={"id":job_id,"user_id":user_id,"status":"queued","progress":2,"style":style,
         "title":Path(video.filename or "Mon YAP").stem[:80],"source_path":str(src),"output_path":None,
         "raw_storage_path":None,"output_storage_path":None,"transcript":None,
         "cuts":None,"render_engine":None,"error":None}
    try:save(job,token)
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise HTTPException(502,"Impossible d'enregistrer le projet dans Supabase.")
    # Starlette background task executes after HTTP response, and thread is bounded by GATE.
    background.add_task(process_job,job_id,note[:800],token)
    return public_job(job)


def set_status(job:dict,status:str,progress:int,token:str,error:str|None=None):
    job.update(status=status,progress=progress,error=error)
    save(job,token)


def storage_upload(bucket:str,path:str,local_file:str,content_type:str,token:str):
    data=Path(local_file).read_bytes()
    with httpx.Client(timeout=150) as client:
        r=client.post(f"{SUPABASE_URL}/storage/v1/object/{bucket}/{quote(path,safe='/')}",
            headers={**supabase_headers(token),"content-type":content_type,"x-upsert":"false"},content=data)
        r.raise_for_status()


def storage_delete(bucket:str,paths:list[str],token:str):
    if not paths:return
    with httpx.Client(timeout=20) as client:
        # Storage API removes a batch of paths.
        r=client.request("DELETE",f"{SUPABASE_URL}/storage/v1/object/{bucket}",headers=supabase_headers(token),json={"prefixes":paths})
        r.raise_for_status()


def process_job(job_id:str,note:str,token:str=""):
    with GATE:
        job=local_job(job_id)
        if not job:return
        folder=WORKDIR/job_id
        src=str(job['source_path'])
        try:
            set_status(job,"analyzing",10,token)
            meta=probe(src)
            silences=detect_silences(src,meta['duration'])
            cuts=intervals_from_silence(meta['duration'],silences)
            transcription={"text":"","words":[]}
            if os.getenv("OPENAI_API_KEY"):
                set_status(job,"transcribing",28,token)
                audio=str(folder/"speech.mp3")
                extract_audio(src,audio)
                transcription=transcribe(audio)
                job['transcript']=transcription['text'][:50000]
                # Claude only has access to timing after real transcription.
                if os.getenv("ANTHROPIC_API_KEY") and transcription['text'].strip():
                    set_status(job,"directing",44,token)
                    try:
                        plan=claude_edit_plan(transcription,meta['duration'],STYLES[job['style']],note)
                        cuts=normalize_cuts(plan.get('cuts',[]),meta['duration'])
                        job['title']=safe_simple_title(plan.get('title','')) or job['title']
                        job['render_engine']='claude+ffmpeg'
                    except (httpx.HTTPError,ValueError,KeyError,json.JSONDecodeError) as exc:
                        # Rendering still proceeds with deterministic cuts; never falsely label as AI edited.
                        job['render_engine']='silence+ffmpeg'
                else:
                    job['render_engine']='silence+ffmpeg'
            else:
                job['render_engine']='silence+ffmpeg'
            job['cuts']=json.dumps(cuts)
            set_status(job,"rendering",62,token)
            result_path=str(folder/"output.mp4")
            # Works without any paid API; uses real cuts even in demo mode.
            info=render_ffmpeg(src,result_path,cuts,transcription['words'],job['style'],str(folder))
            # HyperFrames is an opt-in enhanced renderer; FFmpeg is a tested fallback.
            if os.getenv("HYPERFRAMES_ENABLED","false").lower()=="true":
                try:
                    project=create_composition(result_path,str(folder/"hyperframes"),info['duration'],job['title'],STYLES[job['style']])
                    enhanced=str(folder/"hyperframes-output.mp4")
                    render_hyperframes(project,enhanced)
                    if Path(enhanced).is_file() and Path(enhanced).stat().st_size>1000:
                        result_path=enhanced
                        job['render_engine']+=' + hyperframes'
                except Exception:
                    pass  # Roll back to actual FFmpeg output, not a broken render.
            job['output_path']=result_path
            set_status(job,"saving",94,token)
            if CLOUD:
                raw_path=f"{job['user_id']}/{job_id}/source{Path(src).suffix}"
                out_path=f"{job['user_id']}/{job_id}/output.mp4"
                storage_upload("yapr-raw",raw_path,src,{".mov":"video/quicktime",".webm":"video/webm",".m4v":"video/mp4"}.get(Path(src).suffix,"video/mp4"),token)
                storage_upload("yapr-renders",out_path,result_path,"video/mp4",token)
                job['raw_storage_path']=raw_path
                job['output_storage_path']=out_path
            job['status']='completed';job['progress']=100
            save(job,token)
        except Exception as exc:
            # Never return API keys or request headers from provider exceptions to the client.
            job['status']='failed';job['progress']=0
            if isinstance(exc, httpx.HTTPStatusError):
                job['error']='Le service externe a refusé la demande. Vérifie les crédits et clés API côté serveur.'
            elif isinstance(exc, subprocess.TimeoutExpired):
                job['error']='Le rendu a dépassé la durée maximale.'
            else:
                job['error']=str(exc)[:280] if not CLOUD else "Le montage a échoué. Réessaie ou contacte le support."
            try:save(job,token)
            except Exception:pass
        finally:
            # User media stays in Supabase private storage; local temp cleaned in cloud mode.
            if CLOUD:shutil.rmtree(folder,ignore_errors=True)



class ProfileUpdate(BaseModel):
    style:str="impact"
    note:str=""


@app.get("/api/profile")
def get_profile(user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    if not CLOUD:return {"style":"impact","note":""}
    with httpx.Client(timeout=15) as client:
        r=client.get(f"{SUPABASE_URL}/rest/v1/yapr_profiles",
            params={"user_id":"eq."+user_id,"select":"style,note"},headers=supabase_headers(token))
        r.raise_for_status()
        rows=r.json()
        return rows[0] if rows else {"style":"impact","note":""}


@app.put("/api/profile")
def update_profile(profile:ProfileUpdate,user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    if profile.style not in STYLES:raise HTTPException(422,"Style inconnu.")
    if len(profile.note)>800:raise HTTPException(422,"La consigne dépasse 800 caractères.")
    if CLOUD:
        with httpx.Client(timeout=15) as client:
            r=client.post(f"{SUPABASE_URL}/rest/v1/yapr_profiles",
                headers={**supabase_headers(token),"Prefer":"resolution=merge-duplicates,return=minimal"},
                json={"user_id":user_id,"style":profile.style,"note":profile.note})
            r.raise_for_status()
    return {"style":profile.style,"note":profile.note}


@app.get("/api/jobs")
def list_jobs(user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    if CLOUD:
        with httpx.Client(timeout=15) as client:
            r=client.get(f"{SUPABASE_URL}/rest/v1/yapr_jobs",params={"user_id":"eq."+user_id,
                 "select":"id,status,progress,style,title,error,created_at,render_engine","order":"created_at.desc","limit":"30"},headers=supabase_headers(token))
            r.raise_for_status()
            return r.json()
    with conn() as db:
        rows=db.execute("SELECT * FROM jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 30",(user_id,)).fetchall()
    return [public_job(dict(r)) for r in rows]


@app.get("/api/jobs/{job_id}")
def get_job(job_id:str,user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    job=cloud_job(job_id,user_id,token) if CLOUD else local_job(job_id)
    if not job or job['user_id']!=user_id:raise HTTPException(404,"Projet introuvable.")
    return public_job(job)


@app.get("/api/jobs/{job_id}/download")
def download(job_id:str,user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    job=cloud_job(job_id,user_id,token) if CLOUD else local_job(job_id)
    if not job or job['user_id']!=user_id:raise HTTPException(404,"Projet introuvable.")
    if job['status']!='completed':raise HTTPException(409,"La vidéo n'est pas encore prête.")
    if CLOUD:
        path=job.get('output_storage_path')
        if not path:raise HTTPException(404,"Fichier manquant.")
        with httpx.Client(timeout=25) as client:
            r=client.post(f"{SUPABASE_URL}/storage/v1/object/sign/yapr-renders/{quote(path,safe='/')}",
                headers=supabase_headers(token),json={"expiresIn":300,"download":"YAPR-montage.mp4"})
            r.raise_for_status()
            signed=r.json().get('signedURL') or r.json().get('signedUrl')
            if not signed: raise HTTPException(502,"Lien de téléchargement indisponible.")
            if not signed.startswith('/'):raise HTTPException(502,"URL signée invalide.")
            return RedirectResponse(SUPABASE_URL+signed,status_code=302)
    file=job.get('output_path')
    if not file or not Path(file).exists():raise HTTPException(404,"Fichier non disponible.")
    return FileResponse(file,filename="YAPR-montage.mp4",media_type="video/mp4")


@app.delete("/api/jobs/{job_id}",status_code=204)
def delete_job(job_id:str,user_id:str=Depends(require_user),authorization:Annotated[str|None,Header()]=None):
    token=(authorization or "").removeprefix("Bearer ")
    job=cloud_job(job_id,user_id,token) if CLOUD else local_job(job_id)
    if not job or job['user_id']!=user_id:raise HTTPException(404,"Projet introuvable.")
    if job['status'] not in ('completed','failed'):
        raise HTTPException(409,"Suppression possible uniquement après la fin du traitement.")
    if CLOUD:
        if job.get('raw_storage_path'):storage_delete("yapr-raw",[job['raw_storage_path']],token)
        if job.get('output_storage_path'):storage_delete("yapr-renders",[job['output_storage_path']],token)
        with httpx.Client(timeout=15) as client:
            r=client.delete(f"{SUPABASE_URL}/rest/v1/yapr_jobs",params={"id":"eq."+job_id,"user_id":"eq."+user_id},headers=supabase_headers(token))
            r.raise_for_status()
    with conn() as db:db.execute("DELETE FROM jobs WHERE id=? AND user_id=?",(job_id,user_id))
    shutil.rmtree(WORKDIR/job_id,ignore_errors=True)

app.mount("/",StaticFiles(directory=str(ROOT/"static"),html=True),name="static")
