"""Real FFmpeg YAP rendering, deterministic cuts and timed captions."""
import json
import math
import os
import re
import subprocess
from pathlib import Path
from typing import Any

STYLES = {
    "impact": {"name":"Impact", "accent":"C9FF08", "caption_color":"FFFFFF", "font":"DejaVu Sans", "fontsize": 62, "energy":"punchy"},
    "editorial": {"name":"Éditorial", "accent":"F2EBDC", "caption_color":"FFFFFF", "font":"DejaVu Sans", "fontsize": 57, "energy":"measured"},
    "clean": {"name":"Minimal", "accent":"FFFFFF", "caption_color":"FFFFFF", "font":"DejaVu Sans", "fontsize": 53, "energy":"natural"},
}


def run(cmd: list[str], timeout: int = 400) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, text=True, capture_output=True, timeout=timeout, check=True)


def probe(path: str) -> dict:
    result=run(["ffprobe","-v","error","-show_entries","format=duration:stream=codec_type,width,height", "-of", "json",path], 25)
    data=json.loads(result.stdout)
    videos=[s for s in data.get("streams",[]) if s.get("codec_type")=="video"]
    if not videos: raise ValueError("Ce fichier ne contient pas de piste vidéo.")
    return {"duration":float(data.get("format",{}).get("duration",0)),
            "width":int(videos[0].get("width",0)),"height":int(videos[0].get("height",0)),
            "audio":any(s.get("codec_type")=="audio" for s in data.get("streams",[]))}


def extract_audio(source: str, dest: str):
    run(["ffmpeg","-nostdin","-hide_banner","-loglevel","error","-y","-i",source,
         "-vn","-ac","1","-ar","16000","-b:a","64k",dest],300)


def detect_silences(source: str, duration: float) -> list[tuple[float,float]]:
    res=subprocess.run(["ffmpeg","-nostdin","-hide_banner","-i",source,"-af","silencedetect=noise=-36dB:d=0.55", "-f","null","-"],capture_output=True,text=True,timeout=180)
    entries=[]; start=None
    for line in res.stderr.splitlines():
        a=re.search(r"silence_start:\s*([\d.]+)",line)
        b=re.search(r"silence_end:\s*([\d.]+)",line)
        if a: start=float(a.group(1))
        if b and start is not None:
            entries.append((start,min(duration,float(b.group(1)))))
            start=None
    if start is not None: entries.append((start,duration))
    return entries


def intervals_from_silence(duration:float,silences:list[tuple[float,float]])->list[tuple[float,float]]:
    out=[]; cursor=0.0
    for start,end in sorted(silences):
        if end-start < .55: continue
        cut_start=max(cursor,start+.1)
        cut_end=min(duration,end-.12)
        if cut_start-cursor >= .18: out.append((cursor,cut_start))
        cursor=max(cursor,cut_end)
    if duration-cursor >= .18: out.append((cursor,duration))
    return normalize_cuts(out,duration)


def normalize_cuts(raw:list[tuple[float,float]]|list[dict], duration:float) -> list[tuple[float,float]]:
    data=[]
    for pair in raw[:24]:
        try:
            s=float(pair["start"] if isinstance(pair,dict) else pair[0]); e=float(pair["end"] if isinstance(pair,dict) else pair[1])
        except (ValueError,TypeError,KeyError,IndexError): continue
        s=max(0,min(duration,s));e=max(0,min(duration,e))
        if not (math.isfinite(s) and math.isfinite(e)) or e-s<.3: continue
        if data and s<data[-1][1]: s=data[-1][1]
        if e-s>=.3:data.append((s,e))
    return data or [(0,duration)]


def timestamp(sec:float)->str:
    sec=max(sec,0); h=int(sec//3600);m=int(sec//60)%60;s=int(sec)%60;cs=int((sec-int(sec))*100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def map_time(t:float,cuts:list[tuple[float,float]]) -> float|None:
    offset=0.0
    for s,e in cuts:
        if s<=t<=e: return offset+(t-s)
        offset+=e-s
    return None


def escape_ass(t:str)->str:
    # Prevent ASS override injection from AI/user subtitles.
    return t.replace("\\","∖").replace("{","(").replace("}",")").replace("\n"," ").strip()


def make_ass(words:list[dict], cuts:list[tuple[float,float]], dst:str, style_id:str):
    style=STYLES.get(style_id,STYLES["impact"])
    accent=style["accent"]; ass_accent="&H00"+accent[4:6]+accent[2:4]+accent[0:2]
    color="&H00FFFFFF"
    doc=("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 0\nScaledBorderAndShadow: yes\n"
         "[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
         f"Style: Base,{style['font']},{style['fontsize']},{color},{ass_accent},&H00111111,&H66000000,-1,0,0,0,100,100,0,0,1,4,2,2,80,80,345,1\n"
         "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n")
    mapped=[]
    for w in words:
        ss=map_time(float(w.get('start',0)),cuts);ee=map_time(float(w.get('end',0)),cuts)
        if ss is None or ee is None or ee<=ss: continue
        mapped.append((ss,ee,escape_ass(str(w.get('word','')))))
    # stable chunks of up to 4 words / 2.4s
    group=[]
    def flush():
        nonlocal doc,group
        if not group:return
        s=group[0][0];e=max(group[-1][1],s+.2)
        body=" ".join(g[2] for g in group)
        if style_id=="impact" and len(group)>1:
            body=" ".join(g[2] for g in group[:-1])+f" {{\\c{ass_accent}}}"+group[-1][2]
        doc+=f"Dialogue: 0,{timestamp(s)},{timestamp(e)},Base,,0,0,0,,{body}\n"
        group=[]
    for w in mapped:
        if group and (len(group)>=4 or w[0]-group[0][0]>2.25 or w[0]-group[-1][1]>.5):flush()
        group.append(w)
    flush()
    Path(dst).write_text(doc,encoding="utf-8")
    return bool(mapped)


def render_ffmpeg(source:str,dest:str,cuts:list[tuple[float,float]],words:list[dict],style_id:str,workdir:str, on_progress=None):
    info=probe(source)
    if not info['audio']: raise ValueError("Une vidéo YAP doit contenir une piste audio.")
    cuts=normalize_cuts(cuts,info["duration"])
    # Build one output clip per interval, concatenate in order without shell invocation.
    filters=[]
    for i,(s,e) in enumerate(cuts):
        filters.append(f"[0:v]trim=start={s:.3f}:end={e:.3f},setpts=PTS-STARTPTS[v{i}]")
        filters.append(f"[0:a]atrim=start={s:.3f}:end={e:.3f},asetpts=PTS-STARTPTS[a{i}]")
    inputs=''.join(f'[v{i}][a{i}]' for i in range(len(cuts)))
    filters.append(f"{inputs}concat=n={len(cuts)}:v=1:a=1[vcat][acat]")
    # Crop fill to portrait; smaller free-tier preview avoids excessive FFmpeg memory usage.
    w=720 if os.getenv("VIDEO_WIDTH")=="720" else 1080
    h=w*16//9
    filters.append(f"[vcat]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1,fps=30,format=yuv420p[vout]")
    filters.append("[acat]loudnorm=I=-16:TP=-1.5:LRA=11[aout]")
    current='[vout]'; fcomplex=';'.join(filters)
    ass=str(Path(workdir)/"captions.ass")
    if words and make_ass(words,cuts,ass,style_id):
        # Path stays within private temp dir; escaped for FFmpeg filter syntax.
        safe=ass.replace('\\','\\\\').replace(':','\\:').replace("'", "\\'")
        fcomplex+=f";[vout]ass=filename='{safe}'[vsub]"
        current='[vsub]'
    cmd=['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',source,'-filter_complex',fcomplex,
         '-map',current,'-map','[aout]','-c:v','libx264','-preset','veryfast','-crf','24','-r','30',
         '-c:a','aac','-b:a','128k','-movflags','+faststart',dest]
    run(cmd,900)
    if on_progress: on_progress(90)
    return {"duration":round(sum(e-s for s,e in cuts),2),"cuts":cuts,"width":w,"height":h,
            "captioned":bool(words),"engine":"ffmpeg"}
