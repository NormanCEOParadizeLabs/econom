"""Optional HyperFrames overlay project generator (HTML-native motion graphics)."""
from pathlib import Path
from html import escape
import shutil
import subprocess
import json


def create_composition(video_path:str, output_dir:str, duration:float, hook:str, style:dict)->str:
    """Generate a valid HyperFrames composition. The original MP4 must already be cut."""
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True)
    shutil.copy2(video_path,root/"base.mp4")
    title=escape(hook[:110] or "TU PARLES. ÇA MONTE.")
    accent="#"+style["accent"]
    html=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"/><style>
    *{{box-sizing:border-box}}html,body{{margin:0;background:#080808;overflow:hidden;width:1080px;height:1920px}}
    #frame{{position:relative;width:1080px;height:1920px;overflow:hidden}}
    video{{position:absolute;inset:0;width:1080px;height:1920px;object-fit:cover}}
    #hook{{position:absolute;top:170px;left:72px;right:72px;padding:26px 30px;border-radius:22px;
      font:900 77px/1.07 Arial,sans-serif;color:#0b0b0b;background:{accent};letter-spacing:-2px;
      text-transform:uppercase;box-shadow:0 18px 75px #0008;text-wrap:balance}}
    #logo{{position:absolute;bottom:76px;right:68px;font:900 44px Arial,sans-serif;color:white;
      text-shadow:0 2px 18px #000a}}#logo span{{color:{accent}}}
    </style></head><body>
    <div id="frame" data-composition-id="yapr" data-start="0" data-width="1080" data-height="1920">
      <video class="clip" data-start="0" data-duration="{duration:.3f}" data-track-index="0"
             src="base.mp4" playsinline></video>
      <div id="hook" class="clip" data-start="0" data-duration="{min(2.7,duration):.3f}" data-track-index="1">{title}</div>
      <div id="logo" class="clip" data-start="0" data-duration="{duration:.3f}" data-track-index="2">YAPR<span>.</span></div>
    </div><script>
      window.__timelines=window.__timelines || {{}};
      window.__timelines.yapr={{seek:()=>{{}}}};
    </script></body></html>'''
    (root/"index.html").write_text(html,encoding="utf-8")
    (root/"meta.json").write_text(json.dumps({"name":"YAPR branded output","compositions":["index.html"]}),encoding="utf-8")
    return str(root)


def render(project_dir:str, output_path:str):
    cmd=["hyperframes","render","--output",output_path]
    if not shutil.which("hyperframes"):
        raise RuntimeError("Le CLI HyperFrames n'est pas installé.")
    subprocess.run(cmd,cwd=project_dir,check=True,timeout=800,capture_output=True,text=True)
