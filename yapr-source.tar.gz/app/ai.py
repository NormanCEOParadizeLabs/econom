"""Speech transcription and AI edit direction. No credential is sent to the browser."""
import json
import os
import re
from typing import Any
import httpx


def transcribe(path: str) -> dict[str, Any]:
    """Word-level speech recognition. Raises if the service is unavailable."""
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Clé de transcription absente : OPENAI_API_KEY")
    with open(path, "rb") as fp, httpx.Client(timeout=180) as client:
        response = client.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {key}"},
            data={"model": os.getenv("TRANSCRIPTION_MODEL", "whisper-1"),
                  "response_format": "verbose_json", "timestamp_granularities[]": "word"},
            files={"file": ("audio.mp3", fp, "audio/mpeg")},
        )
    response.raise_for_status()
    data = response.json()
    words = [
        {"start": float(w.get("start", 0)), "end": float(w.get("end", 0)), "word": str(w.get("word", "")).strip()}
        for w in data.get("words", []) if w.get("word", "").strip()
    ]
    if not words:
        for chunk in data.get("segments", []):
            words.append({"start": float(chunk["start"]), "end": float(chunk["end"]), "word": chunk["text"].strip()})
    return {"text": data.get("text", ""), "words": words, "language": data.get("language")}


def claude_edit_plan(transcription: dict, duration: float, style: dict, note: str = "") -> dict:
    """Return strictly validated editing guidance. The caller validates ranges independently."""
    key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Clé Claude absente : ANTHROPIC_API_KEY")
    text = transcription.get("text", "")[:22000]
    sample = transcription.get("words", [])[:900]
    prompt = (
        "Tu es un monteur de vidéos talking-head françaises. Tes instructions seront exécutées automatiquement. "
        "N'invente JAMAIS de propos absents de la transcription. Sélectionne des séquences continues avec timestamps exacts; "
        "ne réorganise pas des syllabes ou des mots. Garde les parties fortes, coupe les digressions, "
        "préserve l'intention et les respirations utiles. Pour la première version, choisis 1 à 8 passages, "
        "en ordre chronologique, sans chevauchement, idéalement 30 à 90 secondes au total si le contenu le permet. "
        "Si la vidéo dure moins de 30 secondes, conserve le contenu pertinent. "
        "Le hook est une citation STRICTEMENT présente dans la transcription, pas une invention. "
        "Renvoie un seul objet JSON valide conforme au schéma.\n"
        f"Durée vidéo: {duration:.2f}s\nStyle: {json.dumps(style,ensure_ascii=False)}\n"
        f"Préférence utilisateur: {note[:800]}\nTranscription: {text}\n"
        f"Repères chronologiques: {json.dumps(sample,ensure_ascii=False)}"
    )
    schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type":"string"},
            "hook": {"type":"string"},
            "reasoning_short": {"type":"string"},
            "cuts": {"type":"array", "items":{"type":"object", "additionalProperties":False,
                     "properties":{"start":{"type":"number"},"end":{"type":"number"}},
                     "required":["start","end"]}},
        },
        "required": ["title","hook","reasoning_short","cuts"]
    }
    with httpx.Client(timeout=100) as client:
        res = client.post("https://api.anthropic.com/v1/messages", headers={
            "x-api-key": key, "anthropic-version":"2023-06-01", "content-type":"application/json"}, json={
            "model":os.getenv("CLAUDE_MODEL","claude-sonnet-5-5"),
            "max_tokens":1200,
            "messages":[{"role":"user","content":prompt}],
            "output_config":{"format":{"type":"json_schema","schema":schema}}
        })
    res.raise_for_status()
    payload = res.json()
    block = next((b.get("text","") for b in payload.get("content", []) if b.get("type")=="text"), "")
    return json.loads(block)


def safe_simple_title(text: str) -> str:
    # Avoid trusting a model's output as command input, HTML, or ASS markup.
    return re.sub(r"[{}\\\r\n]", "", text).strip()[:64]
