const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const humanSize = (bytes) => bytes > 1024 ** 2 ? `${(bytes/1024**2).toFixed(1)} Mo` : `${Math.round(bytes/1024)} Ko`;
const STYLE_NAMES = {impact:'Impact', editorial:'Éditorial', clean:'Minimal'};
const STYLE_DESCRIPTIONS = {impact:'Montage dynamique, accent électrique et sous-titres forts.',editorial:'Montage premium, posé et sous-titres élégants.',clean:'Montage naturel, propre et sans effets superflus.'};
const saved = (()=>{try{return JSON.parse(localStorage.getItem('yapr_prefs')||'{}')}catch{return {}}})();
const state = {config:null, sb:null, user:null, video:null, style:saved.style||'impact', note:saved.note||'', job:null, timer:null, previewUrl:null};

function toast(message, error=false){const el=$('#toast');el.textContent=message;el.classList.toggle('error',error);el.classList.remove('hidden');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.add('hidden'),4300)}
function tab(name){
  $$('.view').forEach(e=>e.classList.toggle('active',e.id===`view-${name}`));
  $$('[data-tab]').forEach(e=>e.classList.toggle('active',e.dataset.tab===name));
  if(name==='projects')loadJobs();
  window.scrollTo({top:0,behavior:'smooth'});
}
function selectStyle(id){if(!STYLE_NAMES[id])return;state.style=id;$$('.style-card').forEach(e=>e.classList.toggle('selected',e.dataset.style===id));$('#default-style').value=id;$('#dna-style').textContent=STYLE_NAMES[id];$('#dna-description').textContent=STYLE_DESCRIPTIONS[id]}
async function savePrefs(){
  state.note=$('#default-note').value.trim();
  localStorage.setItem('yapr_prefs',JSON.stringify({style:state.style,note:state.note}));
  $('#edit-note').value=state.note;
  if(state.config?.authRequired&&state.user){
    try{await api('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({style:state.style,note:state.note})})}
    catch(e){toast('Style enregistré sur cet appareil, mais pas dans le cloud.',true);return}
  }
  toast('Ton style a été enregistré !');
}
async function loadProfile(){
  if(!state.config?.authRequired||!state.user)return;
  try{const p=await (await api('/api/profile')).json();if(STYLE_NAMES[p.style])selectStyle(p.style);state.note=p.note||'';$('#default-note').value=state.note;$('#edit-note').value=state.note}
  catch(e){console.warn('Style distant indisponible :',e.message)}
}
function selectVideo(file){
  if(!file)return;
  if(!/\.(mp4|mov|m4v|webm)$/i.test(file.name)){toast('Choisis une vidéo MP4, MOV ou WEBM.',true);return}
  if(file.size > (state.config?.maxUploadMB||50)*1024**2){toast(`Cette vidéo dépasse ${state.config?.maxUploadMB||50} Mo. Choisis un fichier plus léger.`,true);return}
  state.video=file;$('#selected-file').classList.remove('hidden');$('#filename').textContent=file.name;$('#filesize').textContent=humanSize(file.size);$('#drop-title').textContent='Vidéo sélectionnée';$('#drop-subtitle').textContent='Appuie ici pour en choisir une autre';
  $('#start-btn').disabled=!state.config?.ready;setStatus('Vidéo ajoutée','Prête pour le montage.');
}
function setStatus(title,detail,percent=null){$('#status-label').textContent=title;$('#status-detail').textContent=detail;$('#status-percent').textContent=percent==null?'':`${percent}%`;$('#progress-wrap').classList.toggle('hidden',percent==null);if(percent!=null)$('#progress-bar').style.width=`${percent}%`}
function setBusy(isBusy){$('#start-btn').disabled=isBusy||!state.video;$('#start-btn').innerHTML=isBusy?'<span class="spinner">◌</span> Montage en cours…':'<span>✦</span> Monter ma vidéo <span class="arr">↗</span>'}
async function token(){if(!state.sb)return null;const {data}=await state.sb.auth.getSession();return data.session?.access_token||null}
async function api(url,opts={}){const t=await token();const headers={...(opts.headers||{})};if(t)headers.Authorization=`Bearer ${t}`;const response=await fetch(url,{...opts,headers});if(!response.ok){let m=`Erreur ${response.status}`;try{const data=await response.json();m=typeof data.detail==='string'?data.detail:JSON.stringify(data.detail)}catch{}throw new Error(m)}return response}
function showAuth(){if(!state.config?.supabase){toast('Connecte d’abord un projet Supabase.',true);return}$('#auth-modal').classList.remove('hidden')}
function closeAuth(){$('#auth-modal').classList.add('hidden')}
async function authentication(signup=false){
  if(!state.sb)return;
  const email=$('#auth-email').value.trim();const password=$('#auth-password').value;
  if(!email||password.length<8){toast('Entre un e-mail et un mot de passe de 8 caractères minimum.',true);return}
  const {data,error}=signup?await state.sb.auth.signUp({email,password,options:{emailRedirectTo:window.location.origin}}):await state.sb.auth.signInWithPassword({email,password});
  if(error){toast(error.message,true);return}
  if(signup&&!data.session){toast('Vérifie ton e-mail pour activer ton compte.');return}
  state.user=data.user;closeAuth();updateAccount();toast('Bienvenue dans ton studio !');loadProfile();loadJobs();
}
function updateAccount(){const name=state.user?.email||'Invité';$('#account-name').textContent=name.split('@')[0];$('#account-status').textContent=state.user?'Compte sécurisé':'Session locale';$('#logout-button').classList.toggle('hidden',!state.user);$('#mobile-account').textContent=name.charAt(0).toUpperCase()}
async function init(){
  try{state.config=await (await fetch('/api/config')).json()}catch{toast('Le serveur YAPR. est inaccessible.',true);return}
  if(state.config.demo){$('#top-mode').textContent='MODE LOCAL';$('#account-status').textContent='Essai sans compte'}
  $('#size-limit').textContent=`${state.config.maxUploadMB} Mo max.`;
  if(!state.config.capabilities.captions){$('#status-detail').textContent='Les sous-titres nécessitent une clé de transcription.'}
  if(state.config.supabase){
    try{const mod=await import('https://esm.sh/@supabase/supabase-js@2.119.2');
      state.sb=mod.createClient(state.config.supabaseUrl,state.config.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
      const {data:{session}}=await state.sb.auth.getSession();state.user=session?.user||null;updateAccount();await loadProfile();
      state.sb.auth.onAuthStateChange((_event,session)=>{state.user=session?.user||null;updateAccount()});
    }catch{toast('Impossible de charger la connexion Supabase.',true)}
  }
  selectStyle(state.style);
  $('#edit-note').value=state.note;$('#default-note').value=state.note;
  if(state.config.authRequired&&!state.user)showAuth();
  // Detect deployment without the required production backend configuration.
  if(!state.config.ready){setStatus('Configuration requise','Un administrateur doit terminer la connexion Supabase.');$('#start-btn').disabled=true}
}
// NOTE: /api/config exposes only publishable Supabase configuration. No secret key.
async function startJob(){
  if(!state.video)return;
  if(state.config.authRequired&&!state.user){showAuth();return}
  if(!state.config.ready){toast('Connexion Supabase requise.',true);return}
  $('#result-overlay').classList.add('hidden');$('#download-btn').classList.add('hidden');
  $('#result-video').classList.add('hidden');$('#preview-default').classList.remove('hidden');
  if(state.previewUrl){URL.revokeObjectURL(state.previewUrl);state.previewUrl=null}
  setBusy(true);setStatus('Envoi de ta vidéo','On prépare ton studio...',1);
  const body=new FormData();body.append('video',state.video);body.append('style',state.style);body.append('note',$('#edit-note').value||'');
  try{
    const authorization=await token();
    const job=await new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();xhr.open('POST','/api/jobs');if(authorization)xhr.setRequestHeader('Authorization',`Bearer ${authorization}`);
      xhr.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.min(9,Math.round(e.loaded/e.total*9));setStatus('Envoi en cours',`${Math.round(e.loaded/e.total*100)}% du fichier envoyé`,p)}};
      xhr.onload=()=>{if(xhr.status>=200&&xhr.status<300){try{resolve(JSON.parse(xhr.responseText))}catch{reject(new Error('Réponse serveur invalide.'))}}
        else {try{reject(new Error(JSON.parse(xhr.responseText).detail||'Envoi échoué'))}catch(e){reject(e)}}};
      xhr.onerror=()=>reject(new Error('Problème de réseau pendant l’envoi.'));xhr.send(body);
    });
    state.job=job;setStatus('Montage démarré','Ton monteur prépare la vidéo.',10);pollJob();
  }catch(err){setBusy(false);setStatus('Montage non lancé',err.message);toast(err.message,true)}
}
const LABELS={queued:'Dans la file de traitement',analyzing:'Analyse de la vidéo',transcribing:'Transcription des paroles',directing:'Claude choisit les meilleurs passages',rendering:'Montage vidéo en cours',saving:'Enregistrement privé',completed:'Ton Reel est prêt !',failed:'Le montage a échoué'};
async function pollJob(){
  clearTimeout(state.timer);
  if(!state.job)return;
  try{
    const job=await (await api(`/api/jobs/${state.job.id}`)).json();state.job=job;
    setStatus(LABELS[job.status]||'Traitement en cours',job.status==='completed'?'Tu peux visionner et télécharger ton montage.':job.status==='failed'?(job.error||'Réessaie.'):'Tu peux laisser cet onglet ouvert pendant la préparation.',job.progress);
    if(job.status==='completed'){
      setBusy(false);$('#result-overlay').classList.remove('hidden');$('#download-btn').classList.remove('hidden');
      await loadPreview(job.id);loadJobs();return;
    }
    if(job.status==='failed'){setBusy(false);toast(job.error||'Le rendu a échoué.',true);return}
    state.timer=setTimeout(pollJob,2600);
  }catch(err){state.timer=setTimeout(pollJob,5000);setStatus('Connexion momentanément perdue','Nouvelle tentative dans quelques secondes…')}
}
async function loadPreview(id){
  try{
    const r=await api(`/api/jobs/${id}/download`);const blob=await r.blob();
    if(state.previewUrl)URL.revokeObjectURL(state.previewUrl);
    state.previewUrl=URL.createObjectURL(blob);
    const v=$('#result-video');v.src=state.previewUrl;v.classList.remove('hidden');$('#preview-default').classList.add('hidden');
  }catch{toast('Montage terminé. Utilise le bouton de téléchargement pour récupérer le fichier.',true)}
}
async function downloadFile(id){
  try{
    const r=await api(`/api/jobs/${id}/download`);const blob=await r.blob();
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='YAPR-montage.mp4';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  }catch(err){toast(err.message,true)}
}
async function loadJobs(){
  const wrap=$('#jobs-list');if(!state.config?.ready)return;
  if(state.config?.authRequired&&!state.user){wrap.innerHTML='<div class="empty"><strong>Connecte-toi pour voir tes vidéos.</strong></div>';return}
  try{
    const jobs=await (await api('/api/jobs')).json();
    if(!jobs.length){wrap.innerHTML='<div class="empty"><span>▶</span><strong>Aucune vidéo pour le moment</strong><p>Ton premier montage t’attend !</p></div>';return}
    wrap.replaceChildren(...jobs.map(j=>{
      const item=document.createElement('div');item.className='job-card';
      const ico=document.createElement('div');ico.className='job-ico';ico.textContent=j.status==='completed'?'✓':'▶';
      const info=document.createElement('div');info.className='job-info';
      const title=document.createElement('strong');title.textContent=j.title;info.appendChild(title);
      const meta=document.createElement('span');meta.textContent=`${STYLE_NAMES[j.style]||j.style} · ${LABELS[j.status]||j.status} · ${j.progress}%`;info.appendChild(meta);
      const buttons=document.createElement('div');buttons.className='job-actions';
      if(j.status==='completed'){const d=document.createElement('button');d.textContent='↓ Télécharger';d.onclick=()=>downloadFile(j.id);buttons.appendChild(d)}
      if(['completed','failed'].includes(j.status)){const del=document.createElement('button');del.textContent='Supprimer';del.className='danger';del.onclick=async()=>{
        if(!confirm('Supprimer définitivement ce projet et ses vidéos ?'))return;
        try{await api(`/api/jobs/${j.id}`,{method:'DELETE'});toast('Vidéo supprimée.');loadJobs()}catch(e){toast(e.message,true)}
      };buttons.appendChild(del)}
      item.append(ico,info,buttons);return item;
    }));
  }catch(e){wrap.textContent=`Impossible de charger les vidéos : ${e.message}`}
}
$$('[data-tab]').forEach(e=>e.addEventListener('click',()=>tab(e.dataset.tab)));
$$('.style-card').forEach(e=>e.addEventListener('click',()=>selectStyle(e.dataset.style)));
$$('.go-studio').forEach(e=>e.addEventListener('click',()=>tab('studio')));
$('#dropzone').addEventListener('click',()=>$('#video-file').click());
$('#dropzone').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#video-file').click()}});
$('#video-file').addEventListener('change',e=>selectVideo(e.target.files[0]));
$('#dropzone').addEventListener('dragover',e=>{e.preventDefault();e.currentTarget.classList.add('dragover')});
$('#dropzone').addEventListener('dragleave',e=>e.currentTarget.classList.remove('dragover'));
$('#dropzone').addEventListener('drop',e=>{e.preventDefault();e.currentTarget.classList.remove('dragover');selectVideo(e.dataTransfer.files[0])});
$('#file-remove').addEventListener('click',()=>{state.video=null;$('#video-file').value='';$('#selected-file').classList.add('hidden');$('#start-btn').disabled=true;$('#drop-title').textContent='Appuie ici pour ajouter ta vidéo';setStatus('En attente de ta vidéo','Ton prochain Reel commence ici.')});
$('#start-btn').addEventListener('click',startJob);
$('#download-btn').addEventListener('click',()=>state.job&&downloadFile(state.job.id));
$('#default-style').addEventListener('change',e=>selectStyle(e.target.value));
$('#save-style').addEventListener('click',savePrefs);
$('#signin-btn').addEventListener('click',()=>authentication());
$('#signup-btn').addEventListener('click',()=>authentication(true));
$('#close-auth').addEventListener('click',()=>{if(state.config?.authRequired)toast('Tu dois te connecter pour créer des montages.');closeAuth()});
$('#mobile-account').addEventListener('click',()=>{if(state.user)tab('style');else if(state.config?.supabase)showAuth();else toast('Mode local sans compte.')});
$('#logout-button').addEventListener('click',async()=>{await state.sb?.auth.signOut();state.user=null;updateAccount();showAuth()});
init();
